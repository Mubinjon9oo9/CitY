package CollectionData;
/**
 * Перечисление типов правления
 */
public enum Government {
    NULL,
    DESPOTISM,
    COMMUNISM,
    PUPPET_STATE,
    TOTALITARIANISM,
    JUNTA
}
