package InteractiveEditing;

public class OUTofLimitExceptions extends Exception{
    public OUTofLimitExceptions(String message) {
        super(message);
    }
}
