package InteractiveEditing;

import java.io.*;
import java.util.ArrayList;
/**
 * Класс для чтения из файла и конвертирования байтов в текст
 */
public class ReadFile {

    public void readFile(String txt) throws IOException {
        String [] path = txt.split(" ");
        File file = new File(path[1]);
        InputStream IS = new FileInputStream(file);
        BufferedInputStream BIS = new BufferedInputStream(IS);
        int code;
        char letter;
        String word= "";
        while((code = BIS.read())!= -1) {
            if (code != 10 && code!= 32) {
                letter=(char) code;
                word=word+letter;
            }
            if (code == 10){
                System.out.println("\n"+word);
                Main p1 = new Main();
                p1.GetNCheck(word);
                word="";
            }
            if (code == 32){
                word=word+" ";
            }
        }

        BIS.close();
    }
    public String ReadCollectionFile(){
        int code;
        char letter;
        String word= "";
        try {
        File f1 = new File("/Users/mubinjon9009/IdeaProjects/City/src/InteractiveEditing/collection.xml");
        InputStream IS = new FileInputStream(f1);
            BufferedInputStream BIS = new BufferedInputStream(IS);
            while((code = BIS.read())!= -1) {
                if (code != 10 && code != 32) {
                    letter = (char) code;
                    word = word + letter;
                }
                if (code == 10) {
                    word=word+"\n";
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return word;
    }
}
